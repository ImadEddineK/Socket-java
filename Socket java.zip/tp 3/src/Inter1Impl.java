import java.rmi.*;
import java.rmi.server.*;
import java.util.ArrayList;
import java.util.List;


public class Inter1Impl extends UnicastRemoteObject implements Inter1{
	
	static List<List<String>> list_etud = new ArrayList<>();
	static List<List<String>> list_adm = new ArrayList<>();
	static List<String> row = new ArrayList<>();
	
	

	protected Inter1Impl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<List<String>> ajouter_etd(int id, String pw) throws RemoteException {
		row.add(String.valueOf(id)); // premier colonne
        row.add(pw); // 2 eme colonne
        list_etud.add(row); // ajouter la ligne
        return list_etud;
	}

	@Override
	public void supprimer_etd(int id) throws RemoteException {
		for (int i =0; i<list_etud.size();i++) {
			if(String.valueOf(id).matches(list_etud.get(i).get(0))) {
				list_etud.remove(i);
			}
		}
	}

	
	public String information (int id) {
		String message = null;
		if(id == 1) { message = "le nom de l'etudiant est "+serveur.e1.nom;}
		if(id == 2) { message = "le nom de l'etudiant est "+serveur.e2.nom;}
		if(id == 3) { message = "le nom de l'etudiant est "+serveur.e3.nom;}
		return message;
	}
	
	
	@Override
	public String introduir(double[] notes, int id) throws RemoteException {
		
		String nom = null;
		
		if(id == 1) {
			for(int i=0;i<notes.length;i++) {
				serveur.e1.note[i] = notes[i];  
			}
			nom = serveur.e1.nom;
		}
		
		else if(id == 2) {
			for(int i=0;i<notes.length;i++) {
				serveur.e2.note[i] = notes[i];  
			}
			nom = serveur.e2.nom; 
		}
		
		else if(id == 3) {
			for(int i=0;i<notes.length;i++) {
				serveur.e3.note[i] = notes[i];
			}
			nom = serveur.e3.nom;
		}
		
		return "les notes ont ete modifies pour l'etudiant "+nom;
		
		
	}
	
	public double moyenne(int id)throws RemoteException{
		double moyen = 0;
		if(id == 1) { 
			for(int i =0;i<5;i++) {
				moyen  = moyen + serveur.e1.note[i];
			}
			moyen = moyen/5;
		}
		if(id == 2) { 
		for(int i =0;i<5;i++) {
			moyen  = moyen + serveur.e2.note[i];
		}
		moyen = moyen/5;
	}
		if(id == 3) { 
		for(int i =0;i<5;i++) {
			moyen  = moyen + serveur.e3.note[i];
		}
		moyen = moyen/5;
	}
		return moyen;
	}

}

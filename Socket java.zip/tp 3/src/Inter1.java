import java.rmi.*;
import java.util.List;

public interface Inter1 extends Remote{

	public List<List<String>> ajouter_etd(int id, String pw) throws RemoteException;
	public void supprimer_etd(int id) throws RemoteException;
	public String introduir(double [] notes, int id) throws RemoteException;
	public String information (int id) throws RemoteException;
	public double moyenne(int id)throws RemoteException;
	
}

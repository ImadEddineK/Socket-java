
public class etudiant {

	static String nom;
	static int id;
	static double [] note = new double[5];
	
	public etudiant(int id, String nom) {
		this.nom = nom;
		this.id = id;
	}
	
}

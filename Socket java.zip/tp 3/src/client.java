import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.*;

public class client {
	
	static Inter1 obj;
	static Inter2 obj2;
	static int id = 0; static String pw = null; static int client =0;
	static List<List<String>> list_etud = new ArrayList<>();
	static String messageRecupere;
	static JFrame frame = new JFrame();
	static JDialog d = new JDialog();
	static JDialog d2 = new JDialog();
	static JLabel l = new JLabel("Authentification");
	static JLabel l1 = new JLabel("svp donnez votre id");
	static JLabel l2 = new JLabel("svp donnez votre pw");
	static JTextField tf = new JTextField();
	static JPasswordField pf = new JPasswordField();
	static JButton b1 = new JButton("Valider");
	static JButton b2 = new JButton("ajouter un etudiant");
	static JButton b3 = new JButton("supprimer un etudiant");
	static JButton b4 = new JButton("introduire les notes");
	static JButton b5 = new JButton("consulter des info");
	static JButton b7 = new JButton("la moyenne des etudiant");
	static JButton b6 = new JButton("consulter des info");
	static Scanner sc = new Scanner(System.in);
	static double[] notes = new double[5];
	
	

	public static void main(String[] args) {
		
		frame.setLayout(null);
		frame.setBounds(200,200,400,200);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		d.setLayout(null);
		d.setBounds(200,200,400,200);
		d.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		d2.setLayout(null);
		d2.setBounds(200,200,400,80);
		d2.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		
		
		l.setBounds(150, 10, 200, 40); 
		l1.setBounds(10, 32, 200, 40);  tf.setBounds(150, 42, 200, 25);
		l2.setBounds(10, 62, 200, 40);  pf.setBounds(150, 72, 200, 25);
		b1.setBounds(130, 110, 100, 30);
		
		frame.add(l); frame.add(l1); frame.add(tf); frame.add(l2); frame.add(pf); frame.add(b1);
		
		b2.setBounds(100, 10, 200, 20); b3.setBounds(100, 35, 200, 20); b4.setBounds(100, 60, 200, 20); b5.setBounds(100, 85, 200, 20); b7.setBounds(100, 110, 200, 20);
		d.add(b2);  d.add(b3); d.add(b4); d.add(b5); d.add(b7);
		
		b6.setBounds(100, 10, 200, 20);  d2.add(b6);
		

		
		
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				id = Integer.parseInt(tf.getText());
				pw = pf.getText().toString();
				System.out.println(id+" "+pw);
				
				authinf auth;
				try {
					auth = (authinf) Naming.lookup("AUTHENTIFICATION");
					System.out.println("demande de l'authentification");
					client = auth.authentification(id, pw);
					System.out.println("la demande a ete envoyee ");

				} catch (MalformedURLException | RemoteException | NotBoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			
		});
		
			try {
				
				Thread.sleep(10000);
				
				if(client == 1) {obj = (Inter1) Naming.lookup("adm");  d.setVisible(true);}
				if(client == 2) {obj2 = (Inter2) Naming.lookup("etud");  d2.setVisible(true);}
				
				
				
				b2.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						System.out.println("demande d'ajouter un etudiant");
						System.out.println("donnez l'id et le mot de passe ");
						int id = sc.nextInt();  String pw = sc.next();
						try {
							list_etud = obj.ajouter_etd(id, pw);
						} catch (RemoteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println("la liste apres l'ajout "+list_etud);
					}
					
				});
				
				
				b4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						System.out.println("introduire les notes :");
						System.out.println("introduire l'id de l'etudiant :");
						int id = sc.nextInt();
						System.out.println("donnez les notes :");
						for(int i=0;i<5;i++) {
							notes[i] = sc.nextInt();
						}
						try {
							messageRecupere = obj.introduir(notes, id);
						} catch (RemoteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println(messageRecupere);
					}
					
				});
				
				
				b3.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						System.out.println("demande de supprimer un etudiant");
						System.out.println("donnez l'id ");
						int id = sc.nextInt(); 
						try {
							obj.supprimer_etd(id);
						} catch (RemoteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					
				});
				
				
				b5.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						System.out.println("information pour l'etudiant :");
						System.out.println("introduire l'id de l'etudiant :");
						int id = sc.nextInt();
						try {
							messageRecupere = obj.information(id);
						} catch (RemoteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println(messageRecupere);	
					}
					
				});
				
				
				b7.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						double moy = 0;
						System.out.println("la moyenne :");
						System.out.println("introduire l'id de l'etudiant :");
						int id = sc.nextInt();
						try {
							moy = obj.moyenne(id);
						} catch (RemoteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println(moy);	
					}
					
				});
				
				
				b6.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						System.out.println("information pour l'etudiant :");
						System.out.println("introduire l'id de l'etudiant :");
						int id = sc.nextInt();
						try {
							messageRecupere = obj.information(id);
						} catch (RemoteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println(messageRecupere);	
					}
					
				});
				
				
				
				
				

				System.out.println("c'est bon");
			} catch (MalformedURLException | RemoteException | NotBoundException | InterruptedException  e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}

}

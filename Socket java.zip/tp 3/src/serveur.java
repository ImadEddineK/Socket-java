import java.net.MalformedURLException;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.*;
import java.util.ArrayList;
import java.util.List;

public class serveur{

	static int client = 0;
	
	static etudiant e1 = new etudiant(1, "moh");  static etudiant e2 = new etudiant(2, "riad"); static etudiant e3 = new etudiant(3, "said");
	
	public static void main(String[] args) {
		
		List<String> row = new ArrayList<>();
		row.add("1");  row.add("fnbvt");  Inter1Impl.list_etud.add(row);  row = new ArrayList<>();
		row.add("2");  row.add("thf");  Inter1Impl.list_etud.add(row);  row = new ArrayList<>();
		row.add("3");  row.add("fghc");  Inter1Impl.list_etud.add(row);  row = new ArrayList<>();
		
		row.add("1");  row.add("abcd");  Inter1Impl.list_adm.add(row);  row = new ArrayList<>();
		row.add("2");  row.add("vghn");  Inter1Impl.list_adm.add(row);  row = new ArrayList<>();
		row.add("3");  row.add("dero");  Inter1Impl.list_adm.add(row);  row = new ArrayList<>();
		
		

			try {

				authen auth = new authen();
				Registry register = LocateRegistry.createRegistry(1099);
				Naming.rebind("AUTHENTIFICATION", auth);
				System.out.println("serveur en attent");
				Thread.sleep(12000);
				System.out.println(client);
				
				if(client ==1) {
					System.out.println("ce client est un administrateur");
					Inter1Impl obj1 = new Inter1Impl();
					Naming.rebind("adm", obj1);
				}
				
				else if (client ==2) {
					System.out.println("ce client est un etudiant");
					Inter2Impl obj2 = new Inter2Impl();
					Naming.rebind("etud", obj2);
				}
				
				
				
			} catch (RemoteException | MalformedURLException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
		
		
        
		

	}



}

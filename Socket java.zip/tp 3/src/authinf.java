import java.rmi.Remote;
import java.rmi.RemoteException;

public interface authinf extends Remote{

	public int authentification(int id , String pw) throws RemoteException;
}

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface Inter2 extends Remote{

	public String information (int id) throws RemoteException;
}

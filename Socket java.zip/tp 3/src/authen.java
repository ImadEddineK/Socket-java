import java.rmi.RemoteException;
import java.rmi.server.*;

public class authen extends UnicastRemoteObject implements authinf{

	protected authen() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int authentification(int id, String pw) throws RemoteException {
		int client = 0;
		
		for(int i = 0;i<Inter1Impl.list_etud.size();i++) {
		    if(String.valueOf(id).matches(Inter1Impl.list_etud.get(i).get(0)) &&  pw.matches(Inter1Impl.list_etud.get(i).get(1))) {
		    	serveur.client=2;
                client =2;
		    }
		}
		
		
		for(int i = 0;i<Inter1Impl.list_adm.size();i++) {
		    if(String.valueOf(id).matches(Inter1Impl.list_adm.get(i).get(0)) &&  pw.matches(Inter1Impl.list_adm.get(i).get(1))) {
		    	serveur.client=1;
                client =1;
		    }
		}
		
		
		return client;
	}

}

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Inter2Impl extends UnicastRemoteObject implements Inter2{

	protected Inter2Impl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String information (int id) throws RemoteException{
		String message = null;
		if(id == 1) { message = "le nom de l'etudiant est "+serveur.e1.nom;}
		if(id == 2) { message = "le nom de l'etudiant est "+serveur.e2.nom;}
		if(id == 3) { message = "le nom de l'etudiant est "+serveur.e3.nom;}
		return message;
		
	}

}
